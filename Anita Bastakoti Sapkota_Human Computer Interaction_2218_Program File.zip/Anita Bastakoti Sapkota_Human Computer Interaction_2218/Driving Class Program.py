# -*- coding: utf-8 -*-
"""
Created on Tue Dec 26 13:37:15 2023

@author: 
"""

import tkinter as tk
from tkinter import messagebox
import tkinter.font as font
from PIL import ImageTk, Image
from tkinter import filedialog, simpledialog


# Create the main window
root = tk.Tk()
root.geometry("600x720")
root.title("Pass IT Driving School")
root.configure(bg="light green")
    
def student_button_click():
    show_login_window("Student")

def instructor_button_click():
    show_login_window("Instructor")

def admin_button_click():
    show_login_window("Admin")

def show_login_window(user_type):
    login_window = tk.Toplevel(root)
    login_window.title(f"{user_type} Login")
    login_window.geometry("300x200")
    login_window.configure(bg="light green")

    # Labels and Entry widgets for username and password
    tk.Label(login_window, text="Username:", bg="light green").pack(pady=10)
    username_entry = tk.Entry(login_window)
    username_entry.pack(pady=10)

    tk.Label(login_window, text="Password:", bg="light green").pack(pady=10)
    password_entry = tk.Entry(login_window, show="*")
    password_entry.pack(pady=10)

    # Buttons for login and register
    login_button = tk.Button(login_window, text="Login", bg="white", command=lambda: login(user_type, username_entry.get(), password_entry.get(), login_window))
    login_button.pack(side=tk.LEFT, padx=10)

    register_button = tk.Button(login_window, text="Register", bg="white", command=lambda: register(user_type, username_entry.get(), password_entry.get()))
    register_button.pack(side=tk.RIGHT, padx=10)

def register(user_type, username, password):
    if user_type == "Student":
        new_user = {'name': f"Student_{len(all_students_data) + 1}", 'email': username, 'phone_number': 'N/A'}
        all_students_data.append(new_user)
    elif user_type == "Instructor":
        new_user = {'name': f"Instructor_{len(all_instructors_data) + 1}", 'email': username, 'phone_number': 'N/A', 'full_time': True}
        all_instructors_data.append(new_user)

    # Show registration success message
    messagebox.showinfo("Registration Successful", f"Successfully registered as {user_type}.\nUsername: {username}\nPassword: {password}")

def login(user_type, username, password, login_window):
    messagebox.showinfo("Login", f"Successful {user_type} Login\nUsername: {username}\nPassword: {password}")
    if user_type == "Student":
        show_student_homepage(login_window)
    elif user_type == "Instructor":
        show_instructor_homepage(login_window)
    elif user_type == "Admin":
        show_admin_homepage(login_window)


def show_student_homepage(login_window):
    # Destroy the login window
    login_window.destroy()
    student_window = tk.Toplevel(root)
    student_window.title("Student HomePage")
    student_window.configure(bg="light green")
    student_window.geometry("600x720")

    view_lessons_button = tk.Button(student_window, text="View Lessons", bg="white", command=view_lessons_window, width=17, height=2, font=20)
    view_lessons_button.pack(pady=20)

    view_student_profile_button = tk.Button(student_window, text="View Student Profile", bg="white", command=view_student_profile_window, width=17, height=2, font=20)
    view_student_profile_button.pack(pady=20)
    
    view_booked_lessons_button = tk.Button(student_window, text="View Booked Lessons", bg="white", command=lambda: show_booked_lessons(), width=17, height=2, font=20)
    view_booked_lessons_button.pack(pady=20)
    
    # Create a button to view assigned instructor
    #view_assigned_instructor_button = tk.Button(student_window, text="View Assigned Instructor", bg="white", command=view_assigned_instructor(assigned_instructor_name), width=17, height=2, font=20)
    #view_assigned_instructor_button.pack(pady=20)
    
    logout_button = tk.Button(student_window, text="Logout", bg="white", command=lambda: logout(student_window), width=17, height=2, font=20)
    logout_button.pack(pady=20)
    
    
def logout(window_to_close):
    window_to_close.destroy()

def view_lessons_window():
    lessons_window = tk.Toplevel(root)
    lessons_window.title("View Lessons")
    lessons_window.configure(bg="light green")
    
    for lesson in lessons_data:
        # Frame to contain each lesson's details and book button
        lesson_frame = tk.Frame(lessons_window, bg="light green")
        lesson_frame.pack(fill=tk.X, pady=10)

        # Display lessons information in the left part of the frame
        lessons_info = tk.Text(lesson_frame, width=40, height=5)
        lessons_info.pack(side=tk.LEFT, padx=10)

        lessons_info.insert(tk.END, f"Type: {lesson['type']}\nInstructor: {lesson['instructor']}\nDuration: {lesson['duration']} hour(s)\nFee: ${lesson['fee']}\n")

        lessons_info.config(state=tk.DISABLED)  # Make the text widget read-only

        # Create a book button on the right part of the frame
        book_button = tk.Button(lesson_frame, text="Book", bg="white", command=lambda l=lesson: book_lesson(l))
        book_button.pack(side=tk.RIGHT, padx=10)

def book_lesson(lesson):
    lesson_id = lesson["type"]  # Using a unique identifier for each lesson

    if lesson_id not in booked_lessons_data:
        booked_lessons_data[lesson_id] = lesson
        messagebox.showinfo("Book Lesson", f"Booked lesson:\nType: {lesson['type']}\nInstructor: {lesson['instructor']}\nDuration: {lesson['duration']} hour(s)\nFee: ${lesson['fee']}")
    else:
        messagebox.showinfo("Book Lesson", "Lesson already booked!")

def show_booked_lessons():
    booked_lessons_window = tk.Toplevel(root)
    booked_lessons_window.title("Booked Lessons")
    booked_lessons_window.configure(bg="light green")

    for lesson_id, lesson in booked_lessons_data.items():
        # Frame to contain each booked lesson's details and cancel button
        booked_lesson_frame = tk.Frame(booked_lessons_window, bg="light green")
        booked_lesson_frame.pack(fill=tk.X, pady=10)

        # Display booked lesson information in the left part of the frame
        booked_lesson_info = tk.Text(booked_lesson_frame, width=40, height=5)
        booked_lesson_info.pack(side=tk.LEFT, padx=10)
        
        booked_lesson_info.insert(tk.END, f"Type: {lesson['type']}\nInstructor: {lesson['instructor']}\nDuration: {lesson['duration']} hour(s)\nFee: ${lesson['fee']}\n")

        booked_lesson_info.config(state=tk.DISABLED)  # Make the text widget read-only

        # Create a cancel button on the right part of the frame
        cancel_button = tk.Button(booked_lesson_frame, text="Cancel", bg="white", command=lambda id=lesson_id: cancel_lesson(id))
        cancel_button.pack(side=tk.RIGHT, padx=10)

def cancel_lesson(lesson_id):
    if lesson_id in booked_lessons_data:
        lesson = booked_lessons_data.pop(lesson_id)
        messagebox.showinfo("Cancel Lesson", f"Canceled lesson:\nType: {lesson['type']}\nInstructor: {lesson['instructor']}\nDuration: {lesson['duration']} hour(s)\nFee: ${lesson['fee']}")
    else:
        messagebox.showinfo("Cancel Lesson", "Lesson not found or already canceled!")

        
def get_lesson_by_id(lesson_id):
    for lesson in lessons_data:
        if lesson["type"] == lesson_id:
            return lesson
    return None  # Handle the case where the lesson ID is not found

def view_student_profile_window():
    profile_window = tk.Toplevel(root)
    profile_window.title("View Student Profile")
    profile_window.configure(bg="light green")
    profile_window.geometry("600x720")

    # Display student profile information in the new window
    profile_info_frame = tk.Frame(profile_window, bg="light green")
    profile_info_frame.pack(pady=20)

    # Add an image display (for simplicity, a placeholder image is used)
    placeholder_image = Image.open("profile_image.jpeg")
    placeholder_image = ImageTk.PhotoImage(placeholder_image.resize((300, 300)))
    profile_image_label = tk.Label(profile_info_frame, image=placeholder_image, bg="light green")
    profile_image_label.image = placeholder_image  # Keep reference to avoid garbage collection
    profile_image_label.grid(row=0, column=0, padx=10)

    # Add user details directly from the profile dictionary
    tk.Label(profile_info_frame, text=f"Name: {user_profile['name']}", bg="light green", font=("Helvetica", 12)).grid(row=1, column=0, columnspan=2, padx=10)
    tk.Label(profile_info_frame, text=f"Email: {user_profile['email']}", bg="light green", font=("Helvetica", 12)).grid(row=2, column=0, columnspan=2, padx=10)
    tk.Label(profile_info_frame, text=f"Phone Number: {user_profile['phone_number']}", bg="light green", font=("Helvetica", 12)).grid(row=3, column=0, columnspan=2, padx=10)

    # Add a button to update profile details
    update_button = tk.Button(profile_info_frame, text="Update Profile", bg="white", command=lambda type="student": update_profile(profile_window, type), width=12, height=2)
    update_button.grid(row=4, column=0, columnspan=2, pady=10)

    # Add a button to update profile image
    update_image_button = tk.Button(profile_info_frame, text="Update Image", bg="white", command=lambda: update_profile_image(profile_image_label, "student"), width=12, height=2)
    update_image_button.grid(row=5, column=0, columnspan=2, pady=10)


def update_profile_image(profile_image_label):
    file_path = filedialog.askopenfilename(title="Select Image", filetypes=[("Image files", "*.png;*.jpg;*.jpeg;*.gif")])
    if file_path:
        new_image = Image.open(file_path)
        new_image = ImageTk.PhotoImage(new_image.resize((100, 100)))
        profile_image_label.config(image=new_image)
        profile_image_label.image = new_image  # Keep reference to avoid garbage collection

def update_profile(parent_window, profile_type):
    update_window = tk.Toplevel(parent_window)
    update_window.title("Update Profile")
    update_window.geometry("600x720")
    update_window.configure(bg="light green")

    # Labels and Entry widgets for updating name and email
    tk.Label(update_window, text="Name:", bg="light green").pack(pady=10)
    new_name_entry = tk.Entry(update_window)
    new_name_entry.pack(pady=10)

    tk.Label(update_window, text="Email:", bg="light green").pack(pady=10)
    new_email_entry = tk.Entry(update_window)
    new_email_entry.pack(pady=10)

    tk.Label(update_window, text="Phone Number:", bg="light green").pack(pady=10)
    new_phone_number_entry = tk.Entry(update_window)
    new_phone_number_entry.pack(pady=10)

    # Button to confirm the update
    confirm_button = tk.Button(update_window, text="Confirm Update", bg="white", command=lambda: confirm_update(parent_window, new_name_entry.get(), new_email_entry.get(), new_phone_number_entry.get(), profile_type))
    confirm_button.pack(pady=20)


def confirm_update(parent_window, new_name, new_email, new_phone_number, profile_type):
    # Update the user profile information based on the profile type
    if profile_type == "student":
        user_profile['name'] = new_name
        user_profile['email'] = new_email
        user_profile['phone_number'] = new_phone_number
    elif profile_type == "instructor":
        instructor_profile['name'] = new_name
        instructor_profile['email'] = new_email
        instructor_profile['phone_number'] = new_phone_number

    messagebox.showinfo("Update Profile", "Profile updated successfully!")
    parent_window.destroy()  # Close the update window after confirming the update
    if profile_type == "student":
        view_student_profile_window()
    elif profile_type == "instructor":
        show_instructor_profile_window()

def show_instructor_homepage(login_window):
    # Destroy the login window
    login_window.destroy()
    instructor_window = tk.Toplevel(root)
    instructor_window.title("Instructor HomePage")
    instructor_window.configure(bg="light green")
    instructor_window.geometry("600x720")

    view_lessons_button = tk.Button(instructor_window, text="View Lessons", bg="white", command=view_lessons_window, width=17, height=2, font=20)
    view_lessons_button.pack(pady=20)

    # Create a button to create record sheets
    create_record_sheet_button = tk.Button(instructor_window, text="Create Record Sheet", bg="white", command=create_record_sheet, width=17, height=2, font=20)
    create_record_sheet_button.pack(pady=20)
    
    view_instructor_profile_button = tk.Button(instructor_window, text="View Profile", bg="white", command=lambda: show_instructor_profile_window(), width=17, height=2, font=20)
    view_instructor_profile_button.pack(pady=20)

    # Create a button to manage assigned students
    manage_students_button = tk.Button(instructor_window, text="Manage Students", bg="white", command=manage_students, width=17, height=2, font=20)
    manage_students_button.pack(pady=20)
    
    logout_button = tk.Button(instructor_window, text="Logout", bg="white", command=lambda: logout(instructor_window), width=17, height=2, font=20)
    logout_button.pack(pady=20)

def show_instructor_profile_window():
    profile_window = tk.Toplevel(root)
    profile_window.title("View Instructor Profile")
    profile_window.configure(bg="light green")
    profile_window.geometry("600x720")

    # Display instructor profile information in the new window
    profile_info_frame = tk.Frame(profile_window, bg="light green")
    profile_info_frame.pack(pady=20)

    # Add an image display (for simplicity, a placeholder image is used)
    placeholder_image = Image.open("profile_image.jpeg")
    placeholder_image = ImageTk.PhotoImage(placeholder_image.resize((300, 300)))
    profile_image_label = tk.Label(profile_info_frame, image=placeholder_image, bg="light green")
    profile_image_label.image = placeholder_image  # Keep reference to avoid garbage collection
    profile_image_label.grid(row=0, column=0, padx=10)

    # Add user details directly from the profile dictionary
    tk.Label(profile_info_frame, text=f"Name: {instructor_profile['name']}", bg="light green", font=("Helvetica", 12)).grid(row=1, column=0, columnspan=2, padx=10)
    tk.Label(profile_info_frame, text=f"Email: {instructor_profile['email']}", bg="light green", font=("Helvetica", 12)).grid(row=2, column=0, columnspan=2, padx=10)
    tk.Label(profile_info_frame, text=f"Phone Number: {instructor_profile['phone_number']}", bg="light green", font=("Helvetica", 12)).grid(row=3, column=0, columnspan=2, padx=10)

    # Add a button to update profile details for instructors
    update_button = tk.Button(profile_info_frame, text="Update Profile", bg="white", command=lambda type="instructor": update_profile(profile_window, type), width=12, height=2)
    update_button.grid(row=4, column=0, columnspan=2, pady=10)

    # Add a button to update profile image
    update_image_button = tk.Button(profile_info_frame, text="Update Image", bg="white", command=lambda: update_profile_image(profile_image_label, "instructor"), width=12, height=2)
    update_image_button.grid(row=5, column=0, columnspan=2, pady=10)

def show_admin_homepage(login_window):
    admin_window = tk.Toplevel(root)
    admin_window.title("Admin Homepage")
    admin_window.geometry("600x720")
    admin_window.configure(bg="light green")
    
    view_lessons_button = tk.Button(admin_window, text="View Lessons", bg="white", command=view_lessons_window, width=22, height=2, font=20)
    view_lessons_button.pack(pady=20)

    view_booked_lessons_button = tk.Button(admin_window, text="View Booked Lessons", bg="white", command=view_all_booked_lessons, width=22, height=2, font=20)
    view_booked_lessons_button.pack(pady=20)

    cancel_lesson_button = tk.Button(admin_window, text="Cancel Lesson", bg="white", command=cancel_lesson_by_admin, width=22, height=2, font=20)
    cancel_lesson_button.pack(pady=20)
    
    view_all_students_button = tk.Button(admin_window, text="View All Students", bg="white", command=view_all_students, width=22, height=2, font=20)
    view_all_students_button.pack(pady=20)

    view_all_instructors_button = tk.Button(admin_window, text="View All Instructors", bg="white", command=view_all_instructors, width=22, height=2, font=20)
    view_all_instructors_button.pack(pady=20)
    
    view_submitted_worksheets_button = tk.Button(admin_window, text="View Submitted Worksheets", bg="white", command=view_submitted_worksheets, width=22, height=2, font=20)
    view_submitted_worksheets_button.pack(pady=20)

    logout_button = tk.Button(admin_window, text="Logout", bg="white", command=lambda: logout(admin_window), width=22, height=2, font=20)
    logout_button.pack(pady=20)
    
def manage_students():
    manage_students_window = tk.Toplevel(root)
    manage_students_window.title("Manage Assigned Students")
    manage_students_window.geometry("600x720")
    manage_students_window.configure(bg="light green")

    # Display a list of assigned students
    assigned_students_label = tk.Label(manage_students_window, text="Assigned Students", bg="light green", font=("Helvetica", 14))
    assigned_students_label.pack(pady=10)

    # Create a Text widget to display assigned students
    assigned_students_text = tk.Text(manage_students_window, width=30, height=10)
    assigned_students_text.pack(pady=10)

    # Populate the Text widget with assigned students
    assigned_students_text.insert(tk.END, "\n".join(instructor_assigned_students))

    # Create a button to close the window
    close_button = tk.Button(manage_students_window, text="Close", bg="white", command=manage_students_window.destroy, width=12, height=2)
    close_button.pack(pady=20)

def view_assigned_instructor(assigned_instructor_name):
    # Display a message or implement logic to show the assigned instructor for the student
    messagebox.showinfo("Assigned Instructor", f"Your assigned instructor is: {assigned_instructor_name}")
    
# Sample data for instructor's assigned students
instructor_assigned_students = ["Student 1", "Student 2", "Student 3"]

def view_all_booked_lessons():
    booked_lessons_window = tk.Toplevel(root)
    booked_lessons_window.title("All Booked Lessons")
    booked_lessons_window.configure(bg="light green")
    booked_lessons_window.geometry("600x720")

    for lesson_id, lesson in booked_lessons_data.items():
        # Frame to contain each booked lesson's details and cancel button
        booked_lesson_frame = tk.Frame(booked_lessons_window, bg="light green")
        booked_lesson_frame.pack(fill=tk.X, pady=10)

        # Display booked lesson information in the left part of the frame
        booked_lesson_info = tk.Text(booked_lesson_frame, width=40, height=5)
        booked_lesson_info.pack(side=tk.LEFT, padx=10)

        booked_lesson_info.insert(tk.END, f"Type: {lesson['type']}\nInstructor: {lesson['instructor']}\nDuration: {lesson['duration']} hour(s)\nFee: ${lesson['fee']}\n")

        # Get the user details based on the email
        user_details = get_user_details_by_email(lesson['email'])
        if user_details:
            booked_lesson_info.insert(tk.END, f"\nBooked by:\nName: {user_details['name']}\nEmail: {user_details['email']}\nPhone Number: {user_details['phone_number']}")

        booked_lesson_info.config(state=tk.DISABLED)  # Make the text widget read-only

        # Create a cancel button on the right part of the frame
        cancel_button = tk.Button(booked_lesson_frame, text="Cancel", bg="white", command=lambda id=lesson_id: cancel_lesson(id))
        cancel_button.pack(side=tk.RIGHT, padx=10)

def get_user_details_by_email(email):
    # Search for user details based on email in both students and instructors
    for user_profile in all_students_data + all_instructors_data:
        if user_profile['email'] == email:
            return user_profile
    return None  # Return None if the user with the given email is not found


def cancel_lesson_by_admin():
    # Similar to the cancel_lesson function, but with an additional confirmation for the admin
    lesson_id = simpledialog.askstring("Input", "Enter Lesson ID to Cancel:")
    
    if lesson_id is not None:
        if lesson_id in booked_lessons_data:
            lesson = booked_lessons_data.pop(lesson_id)
            messagebox.showinfo("Cancel Lesson", f"Canceled lesson:\nType: {lesson['type']}\nInstructor: {lesson['instructor']}\nDuration: {lesson['duration']} hour(s)\nFee: ${lesson['fee']}")
        else:
            messagebox.showinfo("Cancel Lesson", "Lesson not found or already canceled!")
            
def view_all_students():
    all_students_window = tk.Toplevel(root)
    all_students_window.title("All Students")
    all_students_window.geometry("600x720")
    all_students_window.configure(bg="light green")

    # Display a list of all students
    all_students_label = tk.Label(all_students_window, text="All Students", bg="light green", font=("Helvetica", 14))
    all_students_label.pack(pady=10)

    # Create a Text widget to display all students
    all_students_text = tk.Text(all_students_window, width=40, height=30)
    all_students_text.pack(pady=10)

    # Populate the Text widget with all students
    for student_profile in all_students_data:
        all_students_text.insert(tk.END, f"Name: {student_profile['name']}\nEmail: {student_profile['email']}\nPhone Number: {student_profile['phone_number']}\n\n")

    # Create a button to close the window
    close_button = tk.Button(all_students_window, text="Close", bg="white", command=all_students_window.destroy, width=12, height=2)
    close_button.pack(pady=20)


def view_all_instructors():
    all_instructors_window = tk.Toplevel(root)
    all_instructors_window.title("All Instructors")
    all_instructors_window.geometry("600x720")
    all_instructors_window.configure(bg="light green")

    # Display a list of all instructors
    all_instructors_label = tk.Label(all_instructors_window, text="All Instructors", bg="light green", font=("Helvetica", 14))
    all_instructors_label.pack(pady=10)

    # Create a Text widget to display all instructors
    all_instructors_text = tk.Text(all_instructors_window, width=40, height=30)
    all_instructors_text.pack(pady=10)

    # Populate the Text widget with all instructors
    for instructor_profile in all_instructors_data:
        full_time_status = "Full-time" if instructor_profile.get('full_time') else "Half-time"
        all_instructors_text.insert(tk.END, f"Name: {instructor_profile['name']}\nEmail: {instructor_profile['email']}\nPhone Number: {instructor_profile['phone_number']}\nStatus: {full_time_status}\n\n")

    # Create a button to close the window
    close_button = tk.Button(all_instructors_window, text="Close", bg="white", command=all_instructors_window.destroy, width=12, height=2)
    close_button.pack(pady=20)

# Modify the view_submitted_worksheets function
def view_submitted_worksheets():
    submitted_worksheets_window = tk.Toplevel(root)
    submitted_worksheets_window.title("Submitted Worksheets")
    submitted_worksheets_window.geometry("600x720")
    submitted_worksheets_window.configure(bg="light green")

    # Display a list of submitted worksheets
    submitted_worksheets_label = tk.Label(submitted_worksheets_window, text="Submitted Worksheets", bg="light green", font=("Helvetica", 14))
    submitted_worksheets_label.pack(pady=10)

    # Create a Text widget to display submitted worksheets
    submitted_worksheets_text = tk.Text(submitted_worksheets_window, width=50, height=30)
    submitted_worksheets_text.pack(pady=10)

    # Populate the Text widget with submitted worksheets
    for instructor_profile in all_instructors_data:
        # Check if the instructor has submitted worksheets
        if 'worksheets' in instructor_profile:
            submitted_worksheets_text.insert(tk.END, f"Instructor: {instructor_profile['name']}\n")

            # Display each worksheet for the instructor
            for worksheet in instructor_profile['worksheets']:
                submitted_worksheets_text.insert(tk.END, f"Submitted by: {worksheet['Instructor Name']}\n")
                submitted_worksheets_text.insert(tk.END, f"Date: {worksheet['Date']}\n")
                submitted_worksheets_text.insert(tk.END, f"Student Name: {worksheet['Student Name']}\n")
                submitted_worksheets_text.insert(tk.END, f"Lesson Type: {worksheet['Lesson Type']}\n")
                submitted_worksheets_text.insert(tk.END, f"Progress Details: {worksheet['Progress Details']}\n")
                submitted_worksheets_text.insert(tk.END, "\n")

    # Create a button to close the window
    close_button = tk.Button(submitted_worksheets_window, text="Close", bg="white", command=submitted_worksheets_window.destroy, width=12, height=2)
    close_button.pack(pady=20)


# Modify the create_record_sheet function
def create_record_sheet():
    record_sheet_window = tk.Toplevel(root)
    record_sheet_window.title("Create Record Sheet")
    record_sheet_window.geometry("600x720")
    record_sheet_window.configure(bg="light green")
    
    # Labels and Entry widgets for record sheet details
    tk.Label(record_sheet_window, text="Instructor Name:", bg="light green").pack(pady=10)
    instructor_name_entry = tk.Entry(record_sheet_window)
    instructor_name_entry.pack(pady=10)

    tk.Label(record_sheet_window, text="Date:", bg="light green").pack(pady=10)
    date_entry = tk.Entry(record_sheet_window)
    date_entry.pack(pady=10)

    tk.Label(record_sheet_window, text="Student Name:", bg="light green").pack(pady=10)
    student_name_entry = tk.Entry(record_sheet_window)
    student_name_entry.pack(pady=10)

    tk.Label(record_sheet_window, text="Lesson Type:", bg="light green").pack(pady=10)
    lesson_type_entry = tk.Entry(record_sheet_window)
    lesson_type_entry.pack(pady=10)

    tk.Label(record_sheet_window, text="Progress Details:", bg="light green").pack(pady=10)
    progress_details_entry = tk.Text(record_sheet_window, width=30, height=5)
    progress_details_entry.pack(pady=10)

    # Button to confirm the record sheet creation
    confirm_button = tk.Button(record_sheet_window, text="Confirm", bg="white", command=lambda: confirm_record_sheet(record_sheet_window, instructor_name_entry.get(), date_entry.get(), student_name_entry.get(), lesson_type_entry.get(), progress_details_entry.get("1.0", tk.END)))
    confirm_button.pack(pady=20)

def confirm_record_sheet(parent_window, instructor_name, date, student_name, lesson_type, progress_details):
    record_sheet_data = {
        'Instuctor Name': instructor_name,
        'Date': date,
        'Student Name': student_name,
        'Lesson Type': lesson_type,
        'Progress Details': progress_details
    }

    # Store the submitted worksheet in the instructor's profile
    instructor_profile['worksheets'] = instructor_profile.get('worksheets', [])
    instructor_profile['worksheets'].append(record_sheet_data)
    
    # Display a message or take further actions as needed
    messagebox.showinfo("Record Sheet Created", "Record sheet created successfully!")
    parent_window.destroy()  # Close the record sheet window after confirming the creation


# Sample data for all students and instructors
all_students_data = [
    {'name': 'Student 1', 'email': 'student1@example.com', 'phone_number': '1111111111'},
    {'name': 'Student 2', 'email': 'student2@example.com', 'phone_number': '2222222222'},
]

all_instructors_data = [
    {'name': 'Vin Diesel', 'email': 'vin@diesel.com', 'phone_number': '3333333333', 'full_time': True},
    {'name': 'Paul Walker', 'email': 'paul@walker.com', 'phone_number': '4444444444', 'full_time': False},
    {'name':'Robert Downey Jr.', 'email':'IamIronMan@Tony.com', 'phone_number': '5555555555', 'full_time': True},
]


# Sample instructor profile data
instructor_profile = {
    'name': 'Instructor Name',
    'email': 'Instructor Email address',
    'phone_number': '9876543210'
}

# Sample user profile data
user_profile = {
    'name': 'Your Name',
    'email': 'Email address',
    'phone_number': '1234567890'
}

# Sample data
lessons_data = [
    {"type": "Introductory", "instructor": "Vin Diesel", "duration": 2, "fee": 50},
    {"type": "Standard", "instructor": "Paul Walker", "duration": 1, "fee": 40},
    {"type": "Pass Plus", "instructor": "Robert Downey Jr.", "duration": 3, "fee": 70},
]

# Data structure to store booked lessons
booked_lessons_data = {}

myFont = font.Font(family='Helvetica', size=30)

# Load images
student_image = Image.open("student_image.png")
instructor_image = Image.open("teacher_image.jpeg")
admin_image = Image.open("admin_image.png")

# Resize images if needed
student_image = ImageTk.PhotoImage(student_image.resize((230, 170)))
instructor_image = ImageTk.PhotoImage(instructor_image.resize((230, 170)))
admin_image = ImageTk.PhotoImage(admin_image.resize((230, 170)))

# Create buttons for students, instructors, and admin
student_button = tk.Button(root, text="Student", command=student_button_click, bg="white", width=14, height=3, font=myFont)
instructor_button = tk.Button(root, text="Instructor", command=instructor_button_click, bg="white", width=14, height=3, font=myFont)
admin_button = tk.Button(root, text="Admin", command=admin_button_click, bg="white", width=14, height=3, font=myFont)

# Create labels for images
student_image_label = tk.Label(root, image=student_image, bg="light green")
instructor_image_label = tk.Label(root, image=instructor_image, bg="light green")
admin_image_label = tk.Label(root, image=admin_image, bg="light green")

# Keep references to the PhotoImage objects
photo_references = [student_image, instructor_image, admin_image]

# Place buttons and image labels in the window
student_image_label.grid(row=0, column=0, pady=30, padx=10)
student_button.grid(row=0, column=1, pady=30, padx=10)

instructor_image_label.grid(row=1, column=0, pady=30, padx=10)
instructor_button.grid(row=1, column=1, pady=30, padx=10)

admin_image_label.grid(row=2, column=0, pady=30, padx=10)
admin_button.grid(row=2, column=1, pady=30, padx=10)

# Start the Tkinter event loop
root.mainloop()
